package hari.ex1;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import hari.ex1.model.FullName;
import hari.ex1.model.Student;

public class App 
{
    public static void main( String[] args )
    {
       	FullName fn=new FullName();
    	fn.setFname("sunkari");
    	fn.setMname("harish");
    	fn.setLname("varma");
      Student s=new Student();
      s.setName(fn);
      s.setMarks(45);
      s.setCity("hyderabad");
      s.setEmail("varma@gmail.com");
      s.setGender("male");
      
      Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
      SessionFactory sf=cfg.buildSessionFactory();
      
      Session session=sf.openSession();
      Transaction t= session.beginTransaction();
      
      session.save(s);
      t.commit();
      
      
    }
}
