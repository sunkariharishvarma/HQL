package org.niit.sql_joints_onetoone;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.niit.sql_joints_onetoone.model.Course;
import org.niit.sql_joints_onetoone.model.Student;


public class App 
{
    public static void main( String[] args )
    {
      Course c=new Course();
      Student st=new Student();
      Scanner s=new Scanner(System.in);
    System.out.println("enter course id");
    String cid=s.next();
    System.out.println("enter  cname");
    String cname=s.next();
    System.out.println("enter sid");
    String sid=s.next();
   
    System.out.println("enter student name");
    String name=s.next();
    
    
    
     c.setCname(cname);
      c.setId(cid);
      st.setSid(sid);
      st.setName(name);
      st.setCourse(c);
    
    
      
      Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(Course.class);
      SessionFactory sf=cfg.buildSessionFactory();
      
      Session session=sf.openSession();
      Transaction t= session.beginTransaction();
      
      session.save(st);
     session.save(c);
      t.commit();
    }
}
